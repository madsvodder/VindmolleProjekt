# Development Tips for chart-fx

## git workflows

### Reformat all commits in pull request to adhere to code style

``` bash
$ git rebase origin/master --exec=./formatLastCommit.sh
```
