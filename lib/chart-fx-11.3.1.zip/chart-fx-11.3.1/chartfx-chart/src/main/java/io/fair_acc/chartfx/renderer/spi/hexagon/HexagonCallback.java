package io.fair_acc.chartfx.renderer.spi.hexagon;

public interface HexagonCallback {
    void handle(Hexagon hexagon);
}
