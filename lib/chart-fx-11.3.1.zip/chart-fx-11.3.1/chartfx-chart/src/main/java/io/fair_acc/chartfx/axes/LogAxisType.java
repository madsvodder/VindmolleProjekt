package io.fair_acc.chartfx.axes;

public enum LogAxisType {
    LINEAR_SCALE,
    LOG10_SCALE,
    DB_SCALE
}
