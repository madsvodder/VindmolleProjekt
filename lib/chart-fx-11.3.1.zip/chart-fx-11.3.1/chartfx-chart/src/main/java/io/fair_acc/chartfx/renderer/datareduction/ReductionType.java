package io.fair_acc.chartfx.renderer.datareduction;

public enum ReductionType {
    MIN,
    MAX,
    AVERAGE,
    DOWN_SAMPLE
}